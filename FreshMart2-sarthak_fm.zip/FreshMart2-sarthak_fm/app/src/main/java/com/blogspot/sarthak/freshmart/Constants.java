package com.blogspot.sarthak.freshmart;

public class Constants {

    public static final String FCM_KEY = "AAAA2xWPwJo:APA91bGkH2AwReuPQDJ6dB90XumUiN16jwDat0HilgznoxVtU_4nGUm4wbi8wBfMm8g6RNWPyJWEYYDzvaPNEUVSPZi9pZ3eeTxFypdmUBsj9rcYpLirWvZV8lUHbQJrVL4gopzV5DJl";
    public static final String FCM_TOPIC = "PUSH_NOTIFICATIONS";

    //product categories
    public static final String[] productCategories = {
            "Beverages",
            "Beauty & Personal Care",
            "Baby Kids",
            "Biscuits Snacks & Chocolates",
            "Breakfast & Dairy",
            "Cooking Needs",
            "Frozen Food",
            "Fruits",
            "Pet Cate",
            "Pharmacy",
            "Vegetables",
            "Others"
    };

    public static final String[] productCategories1 = {
            "All",
            "Beverages",
            "Beauty & Personal Care",
            "Baby Kids",
            "Biscuits Snacks & Chocolates",
            "Breakfast & Dairy",
            "Cooking Needs",
            "Frozen Food",
            "Fruits",
            "Pet Cate",
            "Pharmacy",
            "Vegetables",
            "Others"
    };

}
